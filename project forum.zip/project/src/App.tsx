import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { ForumProvider } from './context/ForumContext';
import Home from './pages/Home';
import CategoryPage from './pages/CategoryPage';
import ThreadPage from './pages/ThreadPage';
import NewThreadPage from './pages/NewThreadPage';
import LoginPage from './pages/LoginPage';
import ProfilePage from './pages/ProfilePage';
import SearchPage from './pages/SearchPage';

function App() {
  return (
    <ForumProvider>
      <Router>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/category/:categoryId" element={<CategoryPage />} />
          <Route path="/thread/:threadId" element={<ThreadPage />} />
          <Route path="/new-thread" element={<NewThreadPage />} />
          <Route path="/login" element={<LoginPage />} />
          <Route path="/profile" element={<ProfilePage />} />
          <Route path="/profile/:userId" element={<ProfilePage />} />
          <Route path="/search" element={<SearchPage />} />
        </Routes>
      </Router>
    </ForumProvider>
  );
}

export default App;