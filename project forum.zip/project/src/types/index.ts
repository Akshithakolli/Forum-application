export interface User {
  id: string;
  username: string;
  avatar: string;
  joinedDate: string;
  karma: number;
}

export interface Category {
  id: string;
  name: string;
  description: string;
  icon: string;
}

export interface Thread {
  id: string;
  title: string;
  content: string;
  authorId: string;
  categoryId: string;
  createdAt: string;
  updatedAt: string;
  upvotes: number;
  downvotes: number;
  commentCount: number;
}

export interface Comment {
  id: string;
  threadId: string;
  authorId: string;
  content: string;
  createdAt: string;
  parentId: string | null;
  upvotes: number;
  downvotes: number;
}

export type VoteType = 'upvote' | 'downvote' | null;

export interface UserVote {
  itemId: string;
  itemType: 'thread' | 'comment';
  voteType: VoteType;
}