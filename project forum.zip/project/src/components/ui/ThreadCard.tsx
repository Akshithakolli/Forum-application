import React from 'react';
import { Link } from 'react-router-dom';
import { MessageSquare, Clock } from 'lucide-react';
import { Thread } from '../../types';
import { useForum } from '../../context/ForumContext';
import VoteButtons from './VoteButtons';
import { formatDate } from '../../utils/helpers';

interface ThreadCardProps {
  thread: Thread;
}

const ThreadCard: React.FC<ThreadCardProps> = ({ thread }) => {
  const { getUserById, getThreadById, categories } = useForum();
  const author = getUserById(thread.authorId);
  const category = categories.find(c => c.id === thread.categoryId);
  
  if (!author || !category) return null;

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden transition-all duration-200 hover:shadow-md">
      <div className="flex">
        <div className="p-2 flex-shrink-0 flex items-start justify-center">
          <VoteButtons 
            itemId={thread.id} 
            itemType="thread"
            upvotes={thread.upvotes}
            downvotes={thread.downvotes}
          />
        </div>
        
        <div className="p-4 flex-grow">
          <div className="flex items-center text-xs text-gray-500 mb-1">
            <Link to={`/category/${category.id}`} className="px-2 py-1 bg-gray-100 rounded-full text-xs font-medium text-gray-700 hover:bg-indigo-100 hover:text-indigo-700 transition-colors">
              {category.name}
            </Link>
            <span className="mx-1">•</span>
            <span className="flex items-center">
              Posted by{' '}
              <Link to={`/profile/${author.id}`} className="ml-1 font-medium text-gray-700 hover:text-indigo-600">
                {author.username}
              </Link>
            </span>
            <span className="mx-1">•</span>
            <span className="flex items-center">
              <Clock className="h-3 w-3 mr-1" />
              {formatDate(thread.createdAt)}
            </span>
          </div>
          
          <Link to={`/thread/${thread.id}`}>
            <h3 className="text-lg font-medium text-gray-900 hover:text-indigo-600 transition-colors mb-2">
              {thread.title}
            </h3>
          </Link>
          
          <div className="text-sm text-gray-700 line-clamp-2 mb-3">
            {thread.content}
          </div>
          
          <div className="flex items-center">
            <Link 
              to={`/thread/${thread.id}`}
              className="flex items-center text-sm text-gray-500 hover:text-indigo-600"
            >
              <MessageSquare className="h-4 w-4 mr-1" />
              {thread.commentCount} {thread.commentCount === 1 ? 'comment' : 'comments'}
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ThreadCard;