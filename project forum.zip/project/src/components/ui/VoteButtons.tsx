import React from 'react';
import { ArrowBigUp, ArrowBigDown } from 'lucide-react';
import { useForum } from '../../context/ForumContext';

interface VoteButtonsProps {
  itemId: string;
  itemType: 'thread' | 'comment';
  upvotes: number;
  downvotes: number;
}

const VoteButtons: React.FC<VoteButtonsProps> = ({ 
  itemId, 
  itemType, 
  upvotes, 
  downvotes 
}) => {
  const { currentUser, voteOnThread, voteOnComment, getVoteStatus } = useForum();
  const voteStatus = getVoteStatus(itemId, itemType);
  
  const handleVote = (voteType: 'upvote' | 'downvote') => {
    if (!currentUser) {
      alert('You need to be logged in to vote');
      return;
    }
    
    const newVoteType = voteStatus === voteType ? null : voteType;
    
    if (itemType === 'thread') {
      voteOnThread(itemId, newVoteType);
    } else {
      voteOnComment(itemId, newVoteType);
    }
  };

  return (
    <div className="flex flex-col items-center">
      <button 
        onClick={() => handleVote('upvote')}
        className={`p-1 rounded ${
          voteStatus === 'upvote' 
            ? 'text-green-600' 
            : 'text-gray-400 hover:text-gray-600'
        } transition-colors duration-200`}
        aria-label="Upvote"
      >
        <ArrowBigUp className="h-6 w-6" />
      </button>
      
      <span className={`text-sm font-medium ${
        upvotes > downvotes 
          ? 'text-green-600' 
          : upvotes < downvotes 
            ? 'text-red-600' 
            : 'text-gray-500'
      }`}>
        {upvotes - downvotes}
      </span>
      
      <button 
        onClick={() => handleVote('downvote')}
        className={`p-1 rounded ${
          voteStatus === 'downvote' 
            ? 'text-red-600' 
            : 'text-gray-400 hover:text-gray-600'
        } transition-colors duration-200`}
        aria-label="Downvote"
      >
        <ArrowBigDown className="h-6 w-6" />
      </button>
    </div>
  );
};

export default VoteButtons;