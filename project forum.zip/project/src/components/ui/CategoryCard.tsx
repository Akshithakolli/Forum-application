import React from 'react';
import { Link } from 'react-router-dom';
import * as Icons from 'lucide-react';
import { Category } from '../../types';

interface CategoryCardProps {
  category: Category;
}

const CategoryCard: React.FC<CategoryCardProps> = ({ category }) => {
  // Dynamically get the icon component from lucide-react
  const IconComponent = (Icons as Record<string, React.ComponentType<any>>)[category.icon] || Icons.FileQuestion;

  return (
    <Link 
      to={`/category/${category.id}`}
      className="block bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden transition-all duration-200 hover:shadow-md hover:border-indigo-200"
    >
      <div className="p-5">
        <div className="flex items-center mb-3">
          <div className="p-2 rounded-full bg-indigo-50 text-indigo-600">
            <IconComponent className="h-6 w-6" />
          </div>
          <h3 className="ml-3 text-lg font-medium text-gray-900">{category.name}</h3>
        </div>
        <p className="text-sm text-gray-600">{category.description}</p>
      </div>
    </Link>
  );
};

export default CategoryCard;