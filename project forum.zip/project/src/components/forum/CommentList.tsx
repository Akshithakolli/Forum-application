import React, { useState } from 'react';
import { User } from 'lucide-react';
import { Comment as CommentType } from '../../types';
import { useForum } from '../../context/ForumContext';
import VoteButtons from '../ui/VoteButtons';
import { formatDate } from '../../utils/helpers';
import CommentForm from './CommentForm';

interface CommentListProps {
  threadId: string;
}

interface CommentItemProps {
  comment: CommentType;
  replies: CommentType[];
  level: number;
}

const CommentItem: React.FC<CommentItemProps> = ({ comment, replies, level }) => {
  const { getUserById, currentUser } = useForum();
  const author = getUserById(comment.authorId);
  const [isReplying, setIsReplying] = useState(false);
  
  if (!author) return null;
  
  const maxLevel = 4;
  const actualLevel = Math.min(level, maxLevel);
  const leftPadding = actualLevel * 16; // 16px per level, max 4 levels

  return (
    <div className="animate-fadeIn">
      <div 
        className={`py-4 ${level > 0 ? 'border-l-2 border-gray-100' : ''}`}
        style={{ marginLeft: leftPadding }}
      >
        <div className="flex">
          <div className="flex-shrink-0 mr-2">
            <VoteButtons 
              itemId={comment.id} 
              itemType="comment"
              upvotes={comment.upvotes}
              downvotes={comment.downvotes}
            />
          </div>
          
          <div className="flex-grow">
            <div className="flex items-center mb-2">
              <div className="flex items-center">
                {author.avatar ? (
                  <img 
                    src={author.avatar} 
                    alt={author.username} 
                    className="h-6 w-6 rounded-full" 
                  />
                ) : (
                  <div className="h-6 w-6 rounded-full bg-gray-200 flex items-center justify-center">
                    <User className="h-4 w-4 text-gray-500" />
                  </div>
                )}
                <span className="ml-2 text-sm font-medium text-gray-900">{author.username}</span>
                <span className="ml-2 text-xs text-gray-500">{formatDate(comment.createdAt)}</span>
              </div>
            </div>
            
            <div className="text-sm text-gray-700 mb-2">
              {comment.content}
            </div>
            
            <div className="flex items-center text-xs">
              {currentUser && (
                <button 
                  onClick={() => setIsReplying(!isReplying)}
                  className="text-gray-500 hover:text-indigo-600"
                >
                  {isReplying ? 'Cancel' : 'Reply'}
                </button>
              )}
            </div>
            
            {isReplying && (
              <div className="mt-3">
                <CommentForm 
                  threadId={comment.threadId} 
                  parentId={comment.id}
                  onCommentSubmitted={() => setIsReplying(false)}
                />
              </div>
            )}
          </div>
        </div>
      </div>
      
      {replies.length > 0 && (
        <div>
          {replies.map(reply => (
            <CommentItem 
              key={reply.id} 
              comment={reply} 
              replies={[]} // We're only doing one level of nesting for simplicity
              level={level + 1} 
            />
          ))}
        </div>
      )}
    </div>
  );
};

const CommentList: React.FC<CommentListProps> = ({ threadId }) => {
  const { getCommentsByThread } = useForum();
  const allComments = getCommentsByThread(threadId);
  
  // Get top-level comments
  const topLevelComments = allComments.filter(comment => comment.parentId === null);
  
  // Get replies, organized by parent ID
  const repliesByParentId: Record<string, CommentType[]> = {};
  allComments
    .filter(comment => comment.parentId !== null)
    .forEach(reply => {
      if (reply.parentId) {
        if (!repliesByParentId[reply.parentId]) {
          repliesByParentId[reply.parentId] = [];
        }
        repliesByParentId[reply.parentId].push(reply);
      }
    });

  if (topLevelComments.length === 0) {
    return (
      <div className="text-center py-8 text-gray-500">
        No comments yet. Be the first to share your thoughts!
      </div>
    );
  }

  return (
    <div className="divide-y divide-gray-200">
      {topLevelComments.map(comment => (
        <CommentItem 
          key={comment.id} 
          comment={comment} 
          replies={repliesByParentId[comment.id] || []} 
          level={0} 
        />
      ))}
    </div>
  );
};

export default CommentList;