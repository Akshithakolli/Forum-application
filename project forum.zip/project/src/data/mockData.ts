import { User, Category, Thread, Comment } from '../types';

export const users: User[] = [
  {
    id: '1',
    username: 'sarah_parker',
    avatar: 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=150',
    joinedDate: '2023-02-15',
    karma: 1542
  },
  {
    id: '2',
    username: 'tech_enthusiast',
    avatar: 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=150',
    joinedDate: '2023-04-10',
    karma: 872
  },
  {
    id: '3',
    username: 'design_master',
    avatar: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=150',
    joinedDate: '2023-01-22',
    karma: 2341
  },
  {
    id: '4',
    username: 'js_developer',
    avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=150',
    joinedDate: '2023-05-05',
    karma: 934
  },
  {
    id: '5',
    username: 'community_mod',
    avatar: 'https://images.pexels.com/photos/1674752/pexels-photo-1674752.jpeg?auto=compress&cs=tinysrgb&w=150',
    joinedDate: '2022-11-18',
    karma: 3126
  }
];

export const categories: Category[] = [
  {
    id: '1',
    name: 'Technology',
    description: 'Discuss the latest in tech, programming, and digital innovations',
    icon: 'Laptop'
  },
  {
    id: '2',
    name: 'Design',
    description: 'Share design ideas, UI/UX concepts, and creative inspirations',
    icon: 'Palette'
  },
  {
    id: '3',
    name: 'Gaming',
    description: 'Talk about video games, gaming hardware, and industry news',
    icon: 'Gamepad2'
  },
  {
    id: '4',
    name: 'Science',
    description: 'Explore scientific discoveries, research, and theories',
    icon: 'Atom'
  },
  {
    id: '5',
    name: 'Movies & TV',
    description: 'Discuss films, TV shows, streaming content, and entertainment',
    icon: 'Film'
  },
  {
    id: '6',
    name: 'Books & Literature',
    description: 'For book lovers and literature enthusiasts',
    icon: 'BookOpen'
  }
];

export const threads: Thread[] = [
  {
    id: '1',
    title: 'React 19 Features: What are you most excited about?',
    content: 'With the new React version on the horizon, I\'m curious to hear what features everyone is looking forward to the most. Personally, I can\'t wait for the improved server components and the new hooks.',
    authorId: '1',
    categoryId: '1',
    createdAt: '2024-10-12T09:45:00Z',
    updatedAt: '2024-10-12T09:45:00Z',
    upvotes: 48,
    downvotes: 2,
    commentCount: 7
  },
  {
    id: '2',
    title: 'Minimalism in UI Design: Trend or Timeless?',
    content: 'I\'ve been noticing a shift back toward more detailed UI elements after years of extreme minimalism. Do you think minimalist design is just a trend that\'s fading, or is it a timeless approach to UI?',
    authorId: '3',
    categoryId: '2',
    createdAt: '2024-10-10T14:22:00Z',
    updatedAt: '2024-10-10T16:05:00Z',
    upvotes: 32,
    downvotes: 5,
    commentCount: 9
  },
  {
    id: '3',
    title: 'New Study Shows Benefits of Quantum Computing in Medical Research',
    content: 'A recent peer-reviewed study demonstrated how quantum computing could dramatically accelerate drug discovery and protein folding analysis. What do you think this means for the future of medical research?',
    authorId: '5',
    categoryId: '4',
    createdAt: '2024-10-11T11:17:00Z',
    updatedAt: '2024-10-11T11:17:00Z',
    upvotes: 76,
    downvotes: 1,
    commentCount: 14
  },
  {
    id: '4',
    title: 'The Last of Us Season 2: Expectations and Theories',
    content: 'With filming wrapped up for season 2 of The Last of Us, let\'s discuss what we\'re expecting to see and any theories about how they\'ll adapt the story from the games.',
    authorId: '2',
    categoryId: '5',
    createdAt: '2024-10-09T20:33:00Z',
    updatedAt: '2024-10-09T20:33:00Z',
    upvotes: 104,
    downvotes: 8,
    commentCount: 23
  },
  {
    id: '5',
    title: 'Best JavaScript Framework for 2025?',
    content: 'With all the changes in the JavaScript ecosystem, which framework do you think will dominate in 2025? React still seems strong, but Vue and Svelte are gaining traction, and new options keep emerging.',
    authorId: '4',
    categoryId: '1',
    createdAt: '2024-10-12T16:08:00Z',
    updatedAt: '2024-10-12T16:08:00Z',
    upvotes: 27,
    downvotes: 4,
    commentCount: 18
  },
  {
    id: '6',
    title: 'Must-read fantasy books of 2024 so far',
    content: 'I\'m looking for new fantasy books to read that came out this year. What have been your favorites? I just finished "The Court of Shadows" and loved it.',
    authorId: '1',
    categoryId: '6',
    createdAt: '2024-10-08T08:19:00Z',
    updatedAt: '2024-10-08T08:19:00Z',
    upvotes: 42,
    downvotes: 3,
    commentCount: 16
  }
];

export const comments: Comment[] = [
  {
    id: '1',
    threadId: '1',
    authorId: '2',
    content: 'I\'m most excited about the new rendering optimizations. The demos showing the performance improvements are impressive!',
    createdAt: '2024-10-12T10:12:00Z',
    parentId: null,
    upvotes: 15,
    downvotes: 0
  },
  {
    id: '2',
    threadId: '1',
    authorId: '4',
    content: 'Server components are definitely the biggest game-changer. It\'s going to transform how we build React apps.',
    createdAt: '2024-10-12T10:45:00Z',
    parentId: null,
    upvotes: 12,
    downvotes: 1
  },
  {
    id: '3',
    threadId: '1',
    authorId: '3',
    content: 'I\'m honestly a bit concerned about the learning curve. Each React update seems to introduce major paradigm shifts.',
    createdAt: '2024-10-12T11:30:00Z',
    parentId: null,
    upvotes: 8,
    downvotes: 2
  },
  {
    id: '4',
    threadId: '1',
    authorId: '5',
    content: 'The new error handling system looks promising too. Much better developer experience.',
    createdAt: '2024-10-12T12:04:00Z',
    parentId: null,
    upvotes: 6,
    downvotes: 0
  },
  {
    id: '5',
    threadId: '1',
    authorId: '1',
    content: 'Good point about the error handling. I missed that in the release notes.',
    createdAt: '2024-10-12T12:15:00Z',
    parentId: '4',
    upvotes: 4,
    downvotes: 0
  },
  {
    id: '6',
    threadId: '1',
    authorId: '2',
    content: 'I agree. The learning curve is steep, but the benefits are worth it in my opinion.',
    createdAt: '2024-10-12T13:22:00Z',
    parentId: '3',
    upvotes: 5,
    downvotes: 1
  },
  {
    id: '7',
    threadId: '1',
    authorId: '4',
    content: 'Has anyone tried the new experimental features in the alpha release?',
    createdAt: '2024-10-12T14:01:00Z',
    parentId: null,
    upvotes: 3,
    downvotes: 0
  },
  {
    id: '8',
    threadId: '2',
    authorId: '1',
    content: 'Minimalism is definitely timeless, but I think we\'re seeing a shift toward more "personality" in UI while keeping the core minimalist principles.',
    createdAt: '2024-10-10T15:03:00Z',
    parentId: null,
    upvotes: 11,
    downvotes: 1
  },
  {
    id: '9',
    threadId: '2',
    authorId: '5',
    content: 'I think it depends on the application. For productivity tools, minimalism makes sense. For creative platforms or entertainment, more expressive designs work better.',
    createdAt: '2024-10-10T15:45:00Z',
    parentId: null,
    upvotes: 9,
    downvotes: 0
  }
];