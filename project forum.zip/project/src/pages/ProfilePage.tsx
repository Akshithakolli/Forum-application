import React from 'react';
import { useParams } from 'react-router-dom';
import { Calendar, MessageSquare, ThumbsUp, Award } from 'lucide-react';
import { useForum } from '../context/ForumContext';
import Layout from '../components/layout/Layout';
import ThreadCard from '../components/ui/ThreadCard';
import { formatDate } from '../utils/helpers';

const ProfilePage: React.FC = () => {
  const { userId } = useParams<{ userId: string }>();
  const { 
    getUserById, 
    getThreadsByUser, 
    getCommentsByUser,
    currentUser
  } = useForum();
  
  // Get user data, either from URL parameter or current user
  const targetUserId = userId || currentUser?.id;
  
  if (!targetUserId) return null;
  
  const user = getUserById(targetUserId);
  if (!user) return null;
  
  const userThreads = getThreadsByUser(user.id);
  const userComments = getCommentsByUser(user.id);
  
  // Calculate total upvotes received
  const totalUpvotes = userThreads.reduce((sum, thread) => sum + thread.upvotes, 0) + 
                       userComments.reduce((sum, comment) => sum + comment.upvotes, 0);

  return (
    <Layout>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* User profile header */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden mb-8">
          <div className="bg-gradient-to-r from-indigo-500 to-purple-600 h-32"></div>
          <div className="px-6 py-4 flex flex-col sm:flex-row">
            <div className="-mt-16 sm:-mt-12 mb-4 sm:mb-0 flex-shrink-0">
              <img 
                src={user.avatar} 
                alt={user.username} 
                className="h-24 w-24 sm:h-32 sm:w-32 rounded-full border-4 border-white object-cover" 
              />
            </div>
            <div className="ml-0 sm:ml-6 flex-grow">
              <h1 className="text-2xl font-bold text-gray-900 mb-1">{user.username}</h1>
              <div className="flex flex-wrap gap-2 mb-4 text-sm text-gray-600">
                <div className="flex items-center">
                  <Calendar className="h-4 w-4 mr-1" />
                  Joined {formatDate(user.joinedDate, true)}
                </div>
                <div className="flex items-center">
                  <MessageSquare className="h-4 w-4 mr-1" />
                  {userThreads.length} {userThreads.length === 1 ? 'thread' : 'threads'}
                </div>
                <div className="flex items-center">
                  <ThumbsUp className="h-4 w-4 mr-1" />
                  {totalUpvotes} {totalUpvotes === 1 ? 'upvote' : 'upvotes'}
                </div>
              </div>
              <div className="flex items-center">
                <div className="flex items-center px-3 py-1 bg-indigo-100 text-indigo-800 rounded-full">
                  <Award className="h-4 w-4 mr-1" />
                  <span className="text-sm font-medium">{user.karma} karma</span>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        {/* User threads */}
        <div className="mb-10">
          <h2 className="text-xl font-semibold text-gray-900 mb-6">Threads Created</h2>
          {userThreads.length > 0 ? (
            <div className="space-y-4">
              {userThreads.map(thread => (
                <ThreadCard key={thread.id} thread={thread} />
              ))}
            </div>
          ) : (
            <div className="text-center bg-white py-8 px-4 rounded-lg shadow-sm border border-gray-200">
              <p className="text-gray-600">No threads created yet.</p>
            </div>
          )}
        </div>
        
        {/* Activity summary */}
        <div className="mb-10">
          <h2 className="text-xl font-semibold text-gray-900 mb-6">Activity Summary</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden p-6">
              <h3 className="text-lg font-medium text-gray-900 mb-2">Thread Activity</h3>
              <div className="text-3xl font-bold text-indigo-600 mb-1">{userThreads.length}</div>
              <p className="text-sm text-gray-600">Threads created</p>
            </div>
            
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden p-6">
              <h3 className="text-lg font-medium text-gray-900 mb-2">Comment Activity</h3>
              <div className="text-3xl font-bold text-indigo-600 mb-1">{userComments.length}</div>
              <p className="text-sm text-gray-600">Comments posted</p>
            </div>
            
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden p-6">
              <h3 className="text-lg font-medium text-gray-900 mb-2">Upvote Activity</h3>
              <div className="text-3xl font-bold text-indigo-600 mb-1">{totalUpvotes}</div>
              <p className="text-sm text-gray-600">Total upvotes received</p>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default ProfilePage;