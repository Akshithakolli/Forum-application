import React from 'react';
import { Link } from 'react-router-dom';
import { PlusCircle } from 'lucide-react';
import { useForum } from '../context/ForumContext';
import Layout from '../components/layout/Layout';
import CategoryCard from '../components/ui/CategoryCard';
import ThreadCard from '../components/ui/ThreadCard';

const Home: React.FC = () => {
  const { categories, threads, currentUser } = useForum();
  
  // Get the 5 most recent threads across all categories
  const recentThreads = [...threads]
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, 5);

  return (
    <Layout>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Hero section */}
        <div className="bg-gradient-to-r from-indigo-500 to-purple-600 rounded-xl shadow-lg p-8 mb-10 text-white">
          <div className="max-w-3xl">
            <h1 className="text-3xl md:text-4xl font-bold mb-4">Welcome to Our Community Forum</h1>
            <p className="text-lg mb-6 text-indigo-100">
              Join conversations, share knowledge, and connect with others in our community.
            </p>
            {currentUser ? (
              <Link 
                to="/new-thread" 
                className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-indigo-600 bg-white hover:bg-indigo-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-white"
              >
                <PlusCircle className="mr-2 h-5 w-5" />
                Start a New Discussion
              </Link>
            ) : (
              <Link 
                to="/login" 
                className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-indigo-600 bg-white hover:bg-indigo-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-white"
              >
                Join the Conversation
              </Link>
            )}
          </div>
        </div>
        
        {/* Categories section */}
        <section className="mb-12">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold text-gray-900">Categories</h2>
            <Link 
              to="/categories" 
              className="text-sm font-medium text-indigo-600 hover:text-indigo-800"
            >
              View All Categories
            </Link>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {categories.slice(0, 6).map(category => (
              <CategoryCard key={category.id} category={category} />
            ))}
          </div>
        </section>
        
        {/* Recent threads section */}
        <section>
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold text-gray-900">Recent Discussions</h2>
            <Link 
              to="/threads" 
              className="text-sm font-medium text-indigo-600 hover:text-indigo-800"
            >
              View All Threads
            </Link>
          </div>
          <div className="space-y-4">
            {recentThreads.map(thread => (
              <ThreadCard key={thread.id} thread={thread} />
            ))}
          </div>
        </section>
      </div>
    </Layout>
  );
};

export default Home;