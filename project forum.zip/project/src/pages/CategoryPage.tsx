import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { PlusCircle } from 'lucide-react';
import { useForum } from '../context/ForumContext';
import Layout from '../components/layout/Layout';
import ThreadCard from '../components/ui/ThreadCard';
import * as Icons from 'lucide-react';

const sortOptions = [
  { value: 'recent', label: 'Most Recent' },
  { value: 'votes', label: 'Most Votes' },
  { value: 'comments', label: 'Most Comments' }
];

const CategoryPage: React.FC = () => {
  const { categoryId } = useParams<{ categoryId: string }>();
  const { categories, getThreadsByCategory, currentUser } = useForum();
  const [sortBy, setSortBy] = useState('recent');
  
  if (!categoryId) return null;
  
  const category = categories.find(c => c.id === categoryId);
  if (!category) return null;
  
  // Get threads for this category
  const threads = getThreadsByCategory(categoryId);
  
  // Sort threads
  const sortedThreads = [...threads].sort((a, b) => {
    if (sortBy === 'recent') {
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    } else if (sortBy === 'votes') {
      const aScore = a.upvotes - a.downvotes;
      const bScore = b.upvotes - b.downvotes;
      return bScore - aScore;
    } else if (sortBy === 'comments') {
      return b.commentCount - a.commentCount;
    }
    return 0;
  });
  
  // Dynamically get the icon component
  const IconComponent = (Icons as Record<string, React.ComponentType<any>>)[category.icon] || Icons.FileQuestion;

  return (
    <Layout>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <div className="flex items-center mb-2">
            <div className="p-2 rounded-full bg-indigo-50 text-indigo-600 mr-3">
              <IconComponent className="h-8 w-8" />
            </div>
            <h1 className="text-3xl font-bold text-gray-900">{category.name}</h1>
          </div>
          <p className="text-lg text-gray-600 mb-4">{category.description}</p>
          <div className="flex items-center justify-between">
            <div className="text-sm text-gray-500">
              {threads.length} {threads.length === 1 ? 'thread' : 'threads'} in this category
            </div>
            
            {currentUser && (
              <Link 
                to={`/new-thread?category=${categoryId}`} 
                className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
              >
                <PlusCircle className="mr-2 h-5 w-5" />
                New Thread
              </Link>
            )}
          </div>
        </div>
        
        {/* Sort controls */}
        <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200 mb-6">
          <div className="flex items-center justify-between">
            <div className="text-sm font-medium text-gray-700">Sort by:</div>
            <div className="flex space-x-2">
              {sortOptions.map(option => (
                <button
                  key={option.value}
                  onClick={() => setSortBy(option.value)}
                  className={`px-3 py-1.5 text-sm font-medium rounded-md ${
                    sortBy === option.value
                      ? 'bg-indigo-100 text-indigo-700'
                      : 'text-gray-500 hover:text-gray-700 hover:bg-gray-100'
                  }`}
                >
                  {option.label}
                </button>
              ))}
            </div>
          </div>
        </div>
        
        {/* Thread list */}
        {sortedThreads.length > 0 ? (
          <div className="space-y-4">
            {sortedThreads.map(thread => (
              <ThreadCard key={thread.id} thread={thread} />
            ))}
          </div>
        ) : (
          <div className="text-center bg-white p-8 rounded-lg shadow-sm border border-gray-200">
            <h3 className="text-lg font-medium text-gray-900 mb-2">No threads yet</h3>
            <p className="text-gray-600 mb-4">Be the first to start a discussion in this category!</p>
            {currentUser ? (
              <Link 
                to={`/new-thread?category=${categoryId}`} 
                className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
              >
                <PlusCircle className="mr-2 h-5 w-5" />
                Start a New Thread
              </Link>
            ) : (
              <Link 
                to="/login" 
                className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
              >
                Login to Post
              </Link>
            )}
          </div>
        )}
      </div>
    </Layout>
  );
};

export default CategoryPage;