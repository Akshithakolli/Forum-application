import React, { useEffect, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import Layout from '../components/layout/Layout';
import ThreadForm from '../components/forum/ThreadForm';

const NewThreadPage: React.FC = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const [categoryId, setCategoryId] = useState<string | undefined>(undefined);
  
  useEffect(() => {
    // Check if we have a category from query params
    const params = new URLSearchParams(location.search);
    const category = params.get('category');
    if (category) {
      setCategoryId(category);
    }
  }, [location]);

  return (
    <Layout>
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-gray-900">Create a New Thread</h1>
          <p className="text-gray-600">
            Share your thoughts and start a discussion with the community.
          </p>
        </div>
        
        <ThreadForm categoryId={categoryId} />
      </div>
    </Layout>
  );
};

export default NewThreadPage;