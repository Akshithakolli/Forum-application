import React from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { ArrowLeft, User, Clock, Flag } from 'lucide-react';
import { useForum } from '../context/ForumContext';
import Layout from '../components/layout/Layout';
import CommentList from '../components/forum/CommentList';
import CommentForm from '../components/forum/CommentForm';
import VoteButtons from '../components/ui/VoteButtons';
import { formatDate } from '../utils/helpers';

const ThreadPage: React.FC = () => {
  const { threadId } = useParams<{ threadId: string }>();
  const navigate = useNavigate();
  const { 
    getThreadById, 
    getUserById, 
    getCommentsByThread,
    categories
  } = useForum();
  
  if (!threadId) return null;
  
  const thread = getThreadById(threadId);
  if (!thread) {
    return (
      <Layout>
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-16 text-center">
          <h1 className="text-2xl font-bold text-gray-900 mb-4">Thread Not Found</h1>
          <p className="text-gray-600 mb-8">The thread you're looking for doesn't exist or has been removed.</p>
          <button 
            onClick={() => navigate(-1)}
            className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
          >
            <ArrowLeft className="mr-2 h-5 w-5" />
            Go Back
          </button>
        </div>
      </Layout>
    );
  }
  
  const author = getUserById(thread.authorId);
  const comments = getCommentsByThread(threadId);
  const category = categories.find(c => c.id === thread.categoryId);
  
  if (!author || !category) return null;

  return (
    <Layout>
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Thread header */}
        <div className="mb-8">
          <div className="flex items-center text-sm text-gray-500 mb-2">
            <button 
              onClick={() => navigate(-1)}
              className="inline-flex items-center mr-3 text-gray-500 hover:text-indigo-600"
            >
              <ArrowLeft className="h-4 w-4 mr-1" />
              Back
            </button>
            <span className="mx-1">•</span>
            <Link to={`/category/${category.id}`} className="font-medium text-indigo-600 hover:text-indigo-800">
              {category.name}
            </Link>
          </div>
          
          <h1 className="text-2xl sm:text-3xl font-bold text-gray-900 mb-4">
            {thread.title}
          </h1>
          
          <div className="flex items-center mb-6">
            <Link to={`/profile/${author.id}`} className="flex items-center">
              {author.avatar ? (
                <img 
                  src={author.avatar} 
                  alt={author.username} 
                  className="h-10 w-10 rounded-full" 
                />
              ) : (
                <div className="h-10 w-10 rounded-full bg-gray-200 flex items-center justify-center">
                  <User className="h-6 w-6 text-gray-500" />
                </div>
              )}
              <div className="ml-3">
                <p className="text-sm font-medium text-gray-900">{author.username}</p>
                <div className="flex items-center text-xs text-gray-500">
                  <Clock className="h-3 w-3 mr-1" />
                  {formatDate(thread.createdAt)}
                </div>
              </div>
            </Link>
          </div>
        </div>
        
        {/* Thread content */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden mb-8">
          <div className="p-6 flex">
            <div className="flex-shrink-0 mr-4">
              <VoteButtons 
                itemId={thread.id} 
                itemType="thread"
                upvotes={thread.upvotes}
                downvotes={thread.downvotes}
              />
            </div>
            
            <div className="flex-grow">
              <div className="prose max-w-none text-gray-700">
                {thread.content}
              </div>
              
              <div className="mt-6 text-right">
                <button className="inline-flex items-center text-sm text-gray-500 hover:text-indigo-600">
                  <Flag className="h-4 w-4 mr-1" />
                  Report
                </button>
              </div>
            </div>
          </div>
        </div>
        
        {/* Comment form */}
        <div className="mb-8">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Leave a comment</h3>
          <CommentForm threadId={threadId} />
        </div>
        
        {/* Comments */}
        <div>
          <h3 className="text-lg font-medium text-gray-900 mb-4">
            Comments ({thread.commentCount})
          </h3>
          <CommentList threadId={threadId} />
        </div>
      </div>
    </Layout>
  );
};

export default ThreadPage;