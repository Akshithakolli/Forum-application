import React, { useEffect, useState } from 'react';
import { useLocation, Link } from 'react-router-dom';
import { Search as SearchIcon, User, MessageSquare } from 'lucide-react';
import { useForum } from '../context/ForumContext';
import Layout from '../components/layout/Layout';
import ThreadCard from '../components/ui/ThreadCard';
import { formatDate } from '../utils/helpers';

const SearchPage: React.FC = () => {
  const location = useLocation();
  const { searchContent, getUserById } = useForum();
  const [query, setQuery] = useState('');
  const [activeTab, setActiveTab] = useState<'threads' | 'comments'>('threads');
  const [searchResults, setSearchResults] = useState<{
    threads: ReturnType<typeof searchContent>['threads'];
    comments: ReturnType<typeof searchContent>['comments'];
  }>({ threads: [], comments: [] });

  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const searchQuery = params.get('q');
    
    if (searchQuery) {
      setQuery(searchQuery);
      const results = searchContent(searchQuery);
      setSearchResults(results);
    }
  }, [location.search, searchContent]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (query.trim()) {
      const results = searchContent(query.trim());
      setSearchResults(results);
      
      // Update URL without triggering a navigation
      const urlParams = new URLSearchParams(location.search);
      urlParams.set('q', query.trim());
      window.history.pushState({}, '', `${location.pathname}?${urlParams.toString()}`);
    }
  };

  return (
    <Layout>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-6">Search Results</h1>
          
          <form onSubmit={handleSubmit} className="mb-6">
            <div className="relative">
              <input
                type="text"
                placeholder="Search for threads, comments, or content..."
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                className="block w-full pl-12 pr-4 py-3 border border-gray-300 rounded-lg shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                required
              />
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <SearchIcon className="h-6 w-6 text-gray-400" />
              </div>
              <button
                type="submit"
                className="absolute inset-y-0 right-0 pr-3 flex items-center"
              >
                <span className="px-4 py-1.5 bg-indigo-600 text-white rounded-md text-sm font-medium">
                  Search
                </span>
              </button>
            </div>
          </form>
          
          {query && (
            <p className="text-gray-600">
              {searchResults.threads.length + searchResults.comments.length} results for "{query}"
            </p>
          )}
        </div>
        
        {/* Tabs */}
        <div className="border-b border-gray-200 mb-6">
          <nav className="-mb-px flex space-x-8">
            <button
              onClick={() => setActiveTab('threads')}
              className={`
                whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm
                ${activeTab === 'threads'
                  ? 'border-indigo-600 text-indigo-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'}
              `}
            >
              Threads ({searchResults.threads.length})
            </button>
            <button
              onClick={() => setActiveTab('comments')}
              className={`
                whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm
                ${activeTab === 'comments'
                  ? 'border-indigo-600 text-indigo-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'}
              `}
            >
              Comments ({searchResults.comments.length})
            </button>
          </nav>
        </div>
        
        {/* Results */}
        {activeTab === 'threads' ? (
          <>
            {searchResults.threads.length > 0 ? (
              <div className="space-y-4">
                {searchResults.threads.map(thread => (
                  <ThreadCard key={thread.id} thread={thread} />
                ))}
              </div>
            ) : (
              <div className="text-center bg-white p-8 rounded-lg shadow-sm border border-gray-200">
                <h3 className="text-lg font-medium text-gray-900 mb-2">No threads found</h3>
                <p className="text-gray-600">Try a different search term or check out the comments tab.</p>
              </div>
            )}
          </>
        ) : (
          <>
            {searchResults.comments.length > 0 ? (
              <div className="space-y-4">
                {searchResults.comments.map(comment => {
                  const author = getUserById(comment.authorId);
                  if (!author) return null;
                  
                  return (
                    <div key={comment.id} className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
                      <div className="flex items-center mb-3">
                        <Link to={`/profile/${author.id}`} className="flex items-center">
                          {author.avatar ? (
                            <img 
                              src={author.avatar} 
                              alt={author.username} 
                              className="h-8 w-8 rounded-full mr-2"
                            />
                          ) : (
                            <div className="h-8 w-8 rounded-full bg-gray-200 flex items-center justify-center mr-2">
                              <User className="h-5 w-5 text-gray-500" />
                            </div>
                          )}
                          <span className="font-medium text-gray-900">{author.username}</span>
                        </Link>
                        <span className="mx-2 text-gray-400">•</span>
                        <span className="text-sm text-gray-500">{formatDate(comment.createdAt)}</span>
                      </div>
                      <div className="text-gray-700 mb-3">{comment.content}</div>
                      <Link 
                        to={`/thread/${comment.threadId}`} 
                        className="inline-flex items-center text-sm text-indigo-600 hover:text-indigo-800"
                      >
                        <MessageSquare className="h-4 w-4 mr-1" />
                        View Thread
                      </Link>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="text-center bg-white p-8 rounded-lg shadow-sm border border-gray-200">
                <h3 className="text-lg font-medium text-gray-900 mb-2">No comments found</h3>
                <p className="text-gray-600">Try a different search term or check out the threads tab.</p>
              </div>
            )}
          </>
        )}
      </div>
    </Layout>
  );
};

export default SearchPage;