import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, Category, Thread, Comment, UserVote } from '../types';
import { users, categories, threads, comments } from '../data/mockData';

interface ForumContextProps {
  users: User[];
  categories: Category[];
  threads: Thread[];
  comments: Comment[];
  currentUser: User | null;
  userVotes: UserVote[];
  
  // Authentication
  login: (username: string) => boolean;
  logout: () => void;
  
  // Thread actions
  getThreadsByCategory: (categoryId: string) => Thread[];
  getThreadById: (threadId: string) => Thread | undefined;
  createThread: (thread: Omit<Thread, 'id' | 'createdAt' | 'updatedAt' | 'upvotes' | 'downvotes' | 'commentCount'>) => Thread;
  
  // Comment actions
  getCommentsByThread: (threadId: string) => Comment[];
  createComment: (comment: Omit<Comment, 'id' | 'createdAt' | 'upvotes' | 'downvotes'>) => Comment;
  
  // Voting
  voteOnThread: (threadId: string, voteType: 'upvote' | 'downvote' | null) => void;
  voteOnComment: (commentId: string, voteType: 'upvote' | 'downvote' | null) => void;
  getVoteStatus: (itemId: string, itemType: 'thread' | 'comment') => 'upvote' | 'downvote' | null;
  
  // User
  getUserById: (userId: string) => User | undefined;
  getThreadsByUser: (userId: string) => Thread[];
  getCommentsByUser: (userId: string) => Comment[];
  
  // Search
  searchContent: (query: string) => { threads: Thread[], comments: Comment[] };
}

const ForumContext = createContext<ForumContextProps | undefined>(undefined);

export const ForumProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [userVotes, setUserVotes] = useState<UserVote[]>([]);
  const [allUsers, setAllUsers] = useState<User[]>(users);
  const [allCategories, setAllCategories] = useState<Category[]>(categories);
  const [allThreads, setAllThreads] = useState<Thread[]>(threads);
  const [allComments, setAllComments] = useState<Comment[]>(comments);

  // Load data from localStorage on initialization
  useEffect(() => {
    const storedUser = localStorage.getItem('forum_currentUser');
    if (storedUser) {
      setCurrentUser(JSON.parse(storedUser));
    }

    const storedVotes = localStorage.getItem('forum_userVotes');
    if (storedVotes) {
      setUserVotes(JSON.parse(storedVotes));
    }

    const storedThreads = localStorage.getItem('forum_threads');
    if (storedThreads) {
      setAllThreads(JSON.parse(storedThreads));
    }

    const storedComments = localStorage.getItem('forum_comments');
    if (storedComments) {
      setAllComments(JSON.parse(storedComments));
    }
  }, []);

  // Save data to localStorage when it changes
  useEffect(() => {
    if (currentUser) {
      localStorage.setItem('forum_currentUser', JSON.stringify(currentUser));
    } else {
      localStorage.removeItem('forum_currentUser');
    }
  }, [currentUser]);

  useEffect(() => {
    localStorage.setItem('forum_userVotes', JSON.stringify(userVotes));
  }, [userVotes]);

  useEffect(() => {
    localStorage.setItem('forum_threads', JSON.stringify(allThreads));
  }, [allThreads]);

  useEffect(() => {
    localStorage.setItem('forum_comments', JSON.stringify(allComments));
  }, [allComments]);

  // Authentication functions
  const login = (username: string) => {
    const user = allUsers.find(u => u.username === username);
    if (user) {
      setCurrentUser(user);
      return true;
    }
    return false;
  };

  const logout = () => {
    setCurrentUser(null);
  };

  // Thread functions
  const getThreadsByCategory = (categoryId: string) => {
    return allThreads.filter(thread => thread.categoryId === categoryId);
  };

  const getThreadById = (threadId: string) => {
    return allThreads.find(thread => thread.id === threadId);
  };

  const createThread = (thread: Omit<Thread, 'id' | 'createdAt' | 'updatedAt' | 'upvotes' | 'downvotes' | 'commentCount'>) => {
    if (!currentUser) throw new Error('User must be logged in to create a thread');
    
    const newThread: Thread = {
      ...thread,
      id: Date.now().toString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      upvotes: 0,
      downvotes: 0,
      commentCount: 0
    };
    
    setAllThreads(prev => [newThread, ...prev]);
    return newThread;
  };

  // Comment functions
  const getCommentsByThread = (threadId: string) => {
    return allComments.filter(comment => comment.threadId === threadId);
  };

  const createComment = (comment: Omit<Comment, 'id' | 'createdAt' | 'upvotes' | 'downvotes'>) => {
    if (!currentUser) throw new Error('User must be logged in to comment');
    
    const newComment: Comment = {
      ...comment,
      id: Date.now().toString(),
      createdAt: new Date().toISOString(),
      upvotes: 0,
      downvotes: 0
    };
    
    setAllComments(prev => [newComment, ...prev]);
    
    // Update thread comment count
    setAllThreads(prev => 
      prev.map(thread => 
        thread.id === comment.threadId 
          ? { ...thread, commentCount: thread.commentCount + 1 } 
          : thread
      )
    );
    
    return newComment;
  };

  // Voting functions
  const voteOnThread = (threadId: string, voteType: 'upvote' | 'downvote' | null) => {
    if (!currentUser) throw new Error('User must be logged in to vote');
    
    // Get the current vote for this thread if it exists
    const existingVoteIndex = userVotes.findIndex(
      vote => vote.itemId === threadId && vote.itemType === 'thread'
    );
    
    const existingVote = existingVoteIndex >= 0 ? userVotes[existingVoteIndex] : null;
    
    // Update the threads
    setAllThreads(prev => 
      prev.map(thread => {
        if (thread.id !== threadId) return thread;
        
        let newUpvotes = thread.upvotes;
        let newDownvotes = thread.downvotes;
        
        // Remove the effect of the existing vote if there is one
        if (existingVote) {
          if (existingVote.voteType === 'upvote') newUpvotes--;
          if (existingVote.voteType === 'downvote') newDownvotes--;
        }
        
        // Add the effect of the new vote
        if (voteType === 'upvote') newUpvotes++;
        if (voteType === 'downvote') newDownvotes++;
        
        return {
          ...thread,
          upvotes: newUpvotes,
          downvotes: newDownvotes
        };
      })
    );
    
    // Update the user votes
    if (existingVoteIndex >= 0) {
      if (voteType === null) {
        // Remove the vote
        setUserVotes(prev => prev.filter((_, index) => index !== existingVoteIndex));
      } else {
        // Update the vote
        setUserVotes(prev => 
          prev.map((vote, index) => 
            index === existingVoteIndex 
              ? { ...vote, voteType } 
              : vote
          )
        );
      }
    } else if (voteType !== null) {
      // Add a new vote
      setUserVotes(prev => [
        ...prev, 
        { itemId: threadId, itemType: 'thread', voteType }
      ]);
    }
  };

  const voteOnComment = (commentId: string, voteType: 'upvote' | 'downvote' | null) => {
    if (!currentUser) throw new Error('User must be logged in to vote');
    
    // Get the current vote for this comment if it exists
    const existingVoteIndex = userVotes.findIndex(
      vote => vote.itemId === commentId && vote.itemType === 'comment'
    );
    
    const existingVote = existingVoteIndex >= 0 ? userVotes[existingVoteIndex] : null;
    
    // Update the comments
    setAllComments(prev => 
      prev.map(comment => {
        if (comment.id !== commentId) return comment;
        
        let newUpvotes = comment.upvotes;
        let newDownvotes = comment.downvotes;
        
        // Remove the effect of the existing vote if there is one
        if (existingVote) {
          if (existingVote.voteType === 'upvote') newUpvotes--;
          if (existingVote.voteType === 'downvote') newDownvotes--;
        }
        
        // Add the effect of the new vote
        if (voteType === 'upvote') newUpvotes++;
        if (voteType === 'downvote') newDownvotes++;
        
        return {
          ...comment,
          upvotes: newUpvotes,
          downvotes: newDownvotes
        };
      })
    );
    
    // Update the user votes
    if (existingVoteIndex >= 0) {
      if (voteType === null) {
        // Remove the vote
        setUserVotes(prev => prev.filter((_, index) => index !== existingVoteIndex));
      } else {
        // Update the vote
        setUserVotes(prev => 
          prev.map((vote, index) => 
            index === existingVoteIndex 
              ? { ...vote, voteType } 
              : vote
          )
        );
      }
    } else if (voteType !== null) {
      // Add a new vote
      setUserVotes(prev => [
        ...prev, 
        { itemId: commentId, itemType: 'comment', voteType }
      ]);
    }
  };

  const getVoteStatus = (itemId: string, itemType: 'thread' | 'comment') => {
    if (!currentUser) return null;
    
    const vote = userVotes.find(
      v => v.itemId === itemId && v.itemType === itemType
    );
    
    return vote ? vote.voteType : null;
  };

  // User functions
  const getUserById = (userId: string) => {
    return allUsers.find(user => user.id === userId);
  };

  const getThreadsByUser = (userId: string) => {
    return allThreads.filter(thread => thread.authorId === userId);
  };

  const getCommentsByUser = (userId: string) => {
    return allComments.filter(comment => comment.authorId === userId);
  };

  // Search function
  const searchContent = (query: string) => {
    const normalizedQuery = query.toLowerCase();
    
    const matchedThreads = allThreads.filter(
      thread => 
        thread.title.toLowerCase().includes(normalizedQuery) || 
        thread.content.toLowerCase().includes(normalizedQuery)
    );
    
    const matchedComments = allComments.filter(
      comment => comment.content.toLowerCase().includes(normalizedQuery)
    );
    
    return { threads: matchedThreads, comments: matchedComments };
  };

  const value: ForumContextProps = {
    users: allUsers,
    categories: allCategories,
    threads: allThreads,
    comments: allComments,
    currentUser,
    userVotes,
    
    login,
    logout,
    
    getThreadsByCategory,
    getThreadById,
    createThread,
    
    getCommentsByThread,
    createComment,
    
    voteOnThread,
    voteOnComment,
    getVoteStatus,
    
    getUserById,
    getThreadsByUser,
    getCommentsByUser,
    
    searchContent
  };

  return (
    <ForumContext.Provider value={value}>
      {children}
    </ForumContext.Provider>
  );
};

export const useForum = () => {
  const context = useContext(ForumContext);
  if (context === undefined) {
    throw new Error('useForum must be used within a ForumProvider');
  }
  return context;
};